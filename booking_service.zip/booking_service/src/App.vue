<!-- src/App.vue -->
<script setup>
import NotificationToast from './components/ui/NotificationToast.vue';
</script>

<template>
  <RouterView />
  <NotificationToast />
</template>