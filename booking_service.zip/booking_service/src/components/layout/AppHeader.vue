<!-- src/components/layout/AppHeader.vue -->
<script setup>
import { useRouter } from 'vue-router';
import { useBookingStore } from '../../stores/booking';

const router = useRouter();
const bookingStore = useBookingStore();

// Переход на главную (Landing)
const goToLanding = () => {
  router.push('/');
};

// Выход — тоже на главную
const handleLogout = () => {
  if (confirm('Выйти на главную страницу?')) {
    router.push('/');
  }
};
</script>

<template>
  <header class="app-header">
    <!-- Логотип — ведет на главную -->
    <div class="logo" @click="goToLanding">
      <span class="logo__icon">✎</span> СБР
    </div>

    <!-- Поиск (опционально, скрываем в профиле/админке через проп) -->
    <div v-if="showSearch" class="search-bar">
      <input 
        v-model="bookingStore.searchQuery"
        type="text" 
        placeholder="Поиск ресурсов..." 
        class="search-bar__input" 
      />
    </div>

    <!-- Навигация -->
    <nav class="app-header__nav">
      <RouterLink to="/dashboard" class="nav-link">Дашборд</RouterLink>
      <RouterLink to="/admin" class="nav-link">Управление</RouterLink>
      <RouterLink to="/profile" class="nav-link">Профиль</RouterLink>
      
      <!-- Кнопка выхода на главную -->
      <button class="logout-btn" @click="handleLogout" title="Выйти на главную">
        <span class="logout-btn__icon">⎋</span>
        <span class="logout-btn__text">Выйти</span>
      </button>

      <div class="avatar"></div>
    </nav>
  </header>
</template>

<script>
// Дополнительный скрипт для props
export default {
  props: {
    showSearch: {
      type: Boolean,
      default: true
    }
  }
};
</script>

<style scoped>
.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 32px;
  background: var(--color-white);
  border-bottom: 1px solid var(--color-border);
  gap: 24px;
}

.logo {
  font-size: 20px;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--color-bg-dark);
  cursor: pointer;
  transition: var(--transition);
  flex-shrink: 0;
}

.logo:hover {
  opacity: 0.8;
}

.logo__icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: 2px solid var(--color-bg-dark);
  border-radius: 6px;
  font-size: 16px;
}

.search-bar {
  flex: 1;
  max-width: 400px;
}

.search-bar__input {
  padding: 10px 16px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  width: 100%;
  background: var(--color-bg-light);
  outline: none;
  transition: var(--transition);
  font-size: 14px;
}

.search-bar__input:focus {
  border-color: var(--color-accent);
  background: var(--color-white);
}

.app-header__nav {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-shrink: 0;
}

.nav-link {
  font-size: 14px;
  color: var(--color-text-muted);
  transition: var(--transition);
  padding: 6px 0;
}

.nav-link:hover,
.nav-link.router-link-active {
  color: var(--color-text-main);
  font-weight: 500;
}

/* Кнопка выхода */
.logout-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: transparent;
  font-size: 13px;
  font-weight: 500;
  color: var(--color-text-muted);
  transition: var(--transition);
  cursor: pointer;
}

.logout-btn:hover {
  border-color: var(--color-bg-dark);
  background: var(--color-bg-dark);
  color: var(--color-white);
}

.logout-btn__icon {
  font-size: 14px;
  line-height: 1;
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-image: url('https://i.pravatar.cc/150?img=12');
  background-size: cover;
  flex-shrink: 0;
  cursor: pointer;
}

/* Адаптивность */
@media (max-width: 1024px) {
  .search-bar {
    display: none;
  }
}

@media (max-width: 768px) {
  .app-header {
    padding: 12px 16px;
    flex-wrap: wrap;
  }

  .app-header__nav {
    gap: 12px;
    flex-wrap: wrap;
    width: 100%;
    justify-content: space-between;
  }

  .nav-link {
    font-size: 13px;
  }

  .logout-btn__text {
    display: none;
  }
}
</style>