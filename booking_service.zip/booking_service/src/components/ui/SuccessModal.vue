<!-- src/components/ui/SuccessModal.vue -->
<script setup>
import BaseModal from './BaseModal.vue';

defineProps({
  isOpen: Boolean
});

const emit = defineEmits(['close']);
</script>

<template>
  <BaseModal :is-open="isOpen" title="" @close="emit('close')">
    <div class="success-content">
      <div class="success-icon">✓</div>
      <h3 class="success-title">Отлично!</h3>
      <p class="success-text">
        Ваша заявка на бронирование принята.<br>
        Уведомления отправлены участникам.
      </p>
      <button class="btn btn--primary" @click="emit('close')">Готово</button>
    </div>
  </BaseModal>
</template>

<style scoped>
.success-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 20px 0;
  gap: 16px;
}

.success-icon {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: var(--color-accent);
  color: var(--color-bg-dark);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  font-weight: 700;
}

.success-title {
  font-size: 22px;
  font-weight: 600;
  color: var(--color-text-main);
}

.success-text {
  font-size: 14px;
  color: var(--color-text-muted);
  line-height: 1.6;
}

.success-content .btn {
  margin-top: 8px;
  min-width: 160px;
}
</style>