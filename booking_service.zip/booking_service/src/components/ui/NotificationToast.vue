<!-- src/components/ui/NotificationToast.vue -->
<script setup>
import { computed } from 'vue';
import { useBookingStore } from '../../stores/booking';

const bookingStore = useBookingStore();

// Показываем только последние 3 непрочитанных уведомления
const visibleNotifications = computed(() => 
  bookingStore.notifications.slice(-3)
);

const removeNotification = (id) => {
  bookingStore.markNotificationAsRead(id);
};
</script>

<template>
  <div class="toast-container">
    <TransitionGroup name="toast">
      <div 
        v-for="notif in visibleNotifications" 
        :key="notif.id"
        class="toast"
        :class="`toast--${notif.type}`"
      >
        <span class="toast__icon">
          {{ notif.type === 'success' ? '✓' : notif.type === 'error' ? '!' : 'i' }}
        </span>
        <span class="toast__message">{{ notif.message }}</span>
        <button class="toast__close" @click="removeNotification(notif.id)">✕</button>
      </div>
    </TransitionGroup>
  </div>
</template>

<style scoped>
.toast-container {
  position: fixed;
  top: 80px;
  right: 24px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  z-index: 2000;
  max-width: 360px;
}

.toast {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  background: var(--color-white);
  border-radius: var(--radius-sm);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  border-left: 4px solid var(--color-text-muted);
}

.toast--success {
  border-left-color: #27AE60;
}

.toast--error {
  border-left-color: #E74C3C;
}

.toast--info {
  border-left-color: var(--color-accent);
}

.toast__icon {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--color-bg-light);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 14px;
  flex-shrink: 0;
}

.toast--success .toast__icon {
  background: #E8F8F0;
  color: #27AE60;
}

.toast--error .toast__icon {
  background: #FDEDEC;
  color: #E74C3C;
}

.toast__message {
  flex: 1;
  font-size: 13px;
  color: var(--color-text-main);
}

.toast__close {
  color: var(--color-text-muted);
  font-size: 12px;
}

.toast__close:hover {
  color: var(--color-text-main);
}

/* Анимации */
.toast-enter-active,
.toast-leave-active {
  transition: all 0.3s ease;
}

.toast-enter-from {
  opacity: 0;
  transform: translateX(30px);
}

.toast-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>