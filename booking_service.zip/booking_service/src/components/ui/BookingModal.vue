<!-- src/components/ui/BookingModal.vue -->
<script setup>
import { ref, watch } from 'vue';
import { useBookingStore } from '../../stores/booking';
import BaseModal from './BaseModal.vue';

const props = defineProps({
  isOpen: Boolean
});

const emit = defineEmits(['close', 'success']);

const bookingStore = useBookingStore();

// Форма
const selectedDate = ref('');
const comment = ref('');
const notificationUsers = ref([]);
const showUserDropdown = ref(false);

// Список сотрудников для уведомлений
const teamMembers = [
  { id: 1, name: 'Анна Смирнова', role: 'Руководитель' },
  { id: 2, name: 'Петр Иванов', role: 'Менеджер' },
  { id: 3, name: 'Ольга Козлова', role: 'Дизайнер' },
  { id: 4, name: 'Дмитрий Волков', role: 'Разработчик' },
];

// При открытии модалки подставляем данные из стора
watch(() => props.isOpen, (newVal) => {
  if (newVal) {
    selectedDate.value = bookingStore.currentSelection.date;
    comment.value = '';
    notificationUsers.value = [];
  }
});

const toggleUser = (user) => {
  const index = notificationUsers.value.findIndex(u => u.id === user.id);
  if (index === -1) {
    notificationUsers.value.push(user);
  } else {
    notificationUsers.value.splice(index, 1);
  }
};

const removeUser = (userId) => {
  notificationUsers.value = notificationUsers.value.filter(u => u.id !== userId);
};

const handleSubmit = () => {
  try {
    bookingStore.createBooking({
      resourceId: bookingStore.currentSelection.resourceId,
      resourceTitle: bookingStore.currentSelection.resourceTitle,
      date: selectedDate.value,
      slots: bookingStore.currentSelection.slots.map(s => s.time),
      comment: comment.value,
      notifications: notificationUsers.value.map(u => u.name)
    });
    
    emit('success');
    emit('close');
  } catch (error) {
    alert(error.message);
  }
};
</script>

<template>
  <BaseModal :is-open="isOpen" title="Бронирование" @close="emit('close')">
    <form class="booking-form" @submit.prevent="handleSubmit">
      <!-- Ресурс -->
      <div class="form-group">
        <label class="form-label">Ресурс</label>
        <div class="form-value">{{ bookingStore.currentSelection.resourceTitle }}</div>
      </div>

      <!-- Выбранные слоты -->
      <div class="form-group">
        <label class="form-label">Выбранное время</label>
        <div class="selected-slots">
          <span 
            v-for="slot in bookingStore.currentSelection.slots" 
            :key="slot.id" 
            class="slot-chip"
          >
            {{ slot.time }}
          </span>
        </div>
      </div>

      <!-- Дата -->
      <div class="form-group">
        <label class="form-label">Дата</label>
        <input 
          v-model="selectedDate" 
          type="date" 
          class="form-input" 
          required
        />
      </div>

      <!-- Уведомления -->
      <div class="form-group">
        <label class="form-label">Уведомить</label>
        <div class="notifications">
          <div 
            v-for="user in notificationUsers" 
            :key="user.id" 
            class="user-chip"
          >
            {{ user.name }}
            <button type="button" @click="removeUser(user.id)" class="chip-remove">✕</button>
          </div>
          
          <button 
            type="button" 
            class="add-user-btn" 
            @click="showUserDropdown = !showUserDropdown"
          >
            + Добавить
          </button>

          <!-- Выпадающий список -->
          <div v-if="showUserDropdown" class="user-dropdown">
            <div 
              v-for="user in teamMembers" 
              :key="user.id" 
              class="user-option"
              @click="toggleUser(user)"
            >
              <span class="user-option__name">{{ user.name }}</span>
              <span class="user-option__role">{{ user.role }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Комментарий -->
      <div class="form-group">
        <label class="form-label">Дополнительная информация</label>
        <textarea 
          v-model="comment" 
          class="form-textarea" 
          placeholder="Добавьте комментарий..."
          rows="3"
        ></textarea>
      </div>

      <!-- Кнопки -->
      <div class="form-actions">
        <button type="button" class="btn btn--outline" @click="emit('close')">Отмена</button>
        <button type="submit" class="btn btn--primary">Забронировать</button>
      </div>
    </form>
  </BaseModal>
</template>

<style scoped>
.booking-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--color-text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.form-value {
  font-size: 15px;
  font-weight: 500;
  color: var(--color-text-main);
}

.selected-slots {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.slot-chip {
  padding: 6px 12px;
  background: var(--color-accent);
  color: var(--color-bg-dark);
  border-radius: 16px;
  font-size: 13px;
  font-weight: 500;
}

.form-input,
.form-textarea {
  padding: 12px 16px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  font-size: 14px;
  font-family: inherit;
  outline: none;
  transition: var(--transition);
  background: var(--color-bg-light);
}

.form-input:focus,
.form-textarea:focus {
  border-color: var(--color-accent);
  background: var(--color-white);
}

.form-textarea {
  resize: vertical;
  min-height: 80px;
}

/* Уведомления */
.notifications {
  position: relative;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.user-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  background: var(--color-bg-light);
  border-radius: 16px;
  font-size: 13px;
}

.chip-remove {
  color: var(--color-text-muted);
  font-size: 12px;
}

.chip-remove:hover {
  color: #E74C3C;
}

.add-user-btn {
  padding: 6px 12px;
  border: 1px dashed var(--color-border);
  border-radius: 16px;
  font-size: 13px;
  color: var(--color-text-muted);
  transition: var(--transition);
}

.add-user-btn:hover {
  border-color: var(--color-accent);
  color: var(--color-bg-dark);
}

.user-dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  margin-top: 8px;
  background: var(--color-white);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  box-shadow: var(--shadow-card);
  z-index: 10;
  min-width: 250px;
  max-height: 200px;
  overflow-y: auto;
}

.user-option {
  padding: 10px 16px;
  display: flex;
  justify-content: space-between;
  cursor: pointer;
  transition: var(--transition);
}

.user-option:hover {
  background: var(--color-bg-light);
}

.user-option__name {
  font-size: 14px;
}

.user-option__role {
  font-size: 12px;
  color: var(--color-text-muted);
}

.form-actions {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.form-actions .btn {
  flex: 1;
}
</style>