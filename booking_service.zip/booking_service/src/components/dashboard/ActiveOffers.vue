<!-- src/components/dashboard/ActiveOffers.vue -->
<template>
  <div class="widget">
    <h3 class="widget__title">Активные предложения</h3>
    <div class="offers-list">
      <div class="offer-card">
        <span class="offer-tag">Фотографы</span>
        <button class="btn btn--primary btn--small">Забронировать</button>
      </div>
      <div class="offer-card">
        <span class="offer-tag">Монтаж</span>
        <button class="btn btn--primary btn--small">Забронировать</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.widget {
  background: var(--color-white);
  border-radius: var(--radius-md);
  padding: 20px;
  box-shadow: var(--shadow-card);
}
.widget__title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
}
.offers-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.offer-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  background: var(--color-bg-light);
  border-radius: var(--radius-sm);
}
.offer-tag {
  font-size: 14px;
  font-weight: 500;
}
.btn--small {
  padding: 6px 12px;
  font-size: 12px;
}
</style>