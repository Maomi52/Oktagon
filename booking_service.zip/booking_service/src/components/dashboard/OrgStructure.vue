<!-- src/components/dashboard/OrgStructure.vue -->
<template>
  <div class="widget">
    <h3 class="widget__title">Схема организации</h3>
    <div class="org-list">
      <div class="org-item">
        <span class="org-name">Отдел маркетинга</span>
        <span class="org-count">12 чел.</span>
      </div>
      <div class="org-item">
        <span class="org-name">Отдел разработки</span>
        <span class="org-count">24 чел.</span>
      </div>
      <div class="org-item">
        <span class="org-name">Отдел дизайна</span>
        <span class="org-count">8 чел.</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.widget {
  background: var(--color-white);
  border-radius: var(--radius-md);
  padding: 20px;
  box-shadow: var(--shadow-card);
}

.widget__title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
}

.org-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.org-item {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid var(--color-border);
  font-size: 14px;
}

.org-item:last-child {
  border-bottom: none;
}

.org-count {
  color: var(--color-text-muted);
}
</style>