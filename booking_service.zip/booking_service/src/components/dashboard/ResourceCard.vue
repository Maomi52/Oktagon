<!-- src/components/dashboard/ResourceCard.vue -->
<script setup>
import { ref, computed } from 'vue';

const props = defineProps({
  id: Number,
  title: String,
  description: String,
  image: String,
  slots: Array,
  isPeople: Boolean // флаг для отображения карточек людей
});

const emit = defineEmits(['book']);

const selectedSlotIds = ref([]);

const toggleSlot = (slot) => {
  if (slot.isBooked) return;
  const index = selectedSlotIds.value.indexOf(slot.id);
  if (index === -1) {
    selectedSlotIds.value.push(slot.id);
  } else {
    selectedSlotIds.value.splice(index, 1);
  }
};

const selectedSlots = computed(() => {
  return props.slots.filter(s => selectedSlotIds.value.includes(s.id));
});

const handleBook = () => {
  if (selectedSlots.value.length === 0) {
    alert('Выберите хотя бы один слот времени');
    return;
  }
  emit('book', {
    resourceId: props.id,
    resourceTitle: props.title,
    slots: selectedSlots.value
  });
};
</script>

<template>
  <div class="resource-card" :class="{ 'resource-card--person': isPeople }">
    <div class="resource-card__image-wrapper">
      <img :src="image" :alt="title" class="resource-card__image" />
    </div>
    
    <div class="resource-card__content">
      <div class="resource-card__header">
        <h3 class="resource-card__title">{{ title }}</h3>
        <p class="resource-card__desc">{{ description }}</p>
      </div>

      <div class="resource-card__slots">
        <button 
          v-for="slot in slots" 
          :key="slot.id"
          class="time-slot"
          :class="{ 
            'time-slot--selected': selectedSlotIds.includes(slot.id), 
            'time-slot--booked': slot.isBooked 
          }"
          :disabled="slot.isBooked"
          @click="toggleSlot(slot)"
        >
          {{ slot.time }}
        </button>
      </div>

      <div class="resource-card__actions">
        <button class="btn btn--outline">Отмена</button>
        <button class="btn btn--primary" @click="handleBook">Забронировать</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* Стили остаются прежними, добавляем только для людей */
.resource-card--person .resource-card__image-wrapper {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  align-self: center;
}

.resource-card--person {
  align-items: center;
}

/* Остальные стили из предыдущей версии */
.resource-card {
  background: var(--color-white);
  border-radius: var(--radius-md);
  padding: 16px;
  box-shadow: var(--shadow-card);
  display: flex;
  gap: 20px;
}

.resource-card__image-wrapper {
  flex-shrink: 0;
  width: 200px;
  height: 140px;
  border-radius: var(--radius-sm);
  overflow: hidden;
}

.resource-card__image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.resource-card__content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.resource-card__title {
  font-size: 18px;
  font-weight: 600;
  color: var(--color-text-main);
  margin-bottom: 4px;
}

.resource-card__desc {
  font-size: 13px;
  color: var(--color-text-muted);
}

.resource-card__slots {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
  margin-top: auto;
}

.time-slot {
  padding: 8px 4px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: transparent;
  font-size: 11px;
  font-weight: 500;
  color: var(--color-text-main);
  transition: var(--transition);
  cursor: pointer;
}

.time-slot:hover:not(.time-slot--booked) {
  border-color: var(--color-accent);
}

.time-slot--selected {
  background: var(--color-accent);
  border-color: var(--color-accent);
  color: var(--color-bg-dark);
}

.time-slot--booked {
  background: #F0F0F0;
  color: #B0B0B0;
  cursor: not-allowed;
  border-color: transparent;
}

.resource-card__actions {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.resource-card__actions .btn {
  padding: 8px 16px;
  font-size: 13px;
}

@media (max-width: 768px) {
  .resource-card {
    flex-direction: column;
  }
  
  .resource-card__image-wrapper {
    width: 100%;
    height: 180px;
  }
  
  .resource-card__slots {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>