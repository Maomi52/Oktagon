<!-- src/components/dashboard/CalendarWidget.vue -->
<script setup>
import { ref, computed } from 'vue';

const currentDate = new Date();
const currentMonth = ref(currentDate.getMonth());
const currentYear = ref(currentDate.getFullYear());
const selectedDay = ref(currentDate.getDate());

const daysInMonth = computed(() => {
  return new Date(currentYear.value, currentMonth.value + 1, 0).getDate();
});

const firstDayOfMonth = computed(() => {
  const day = new Date(currentYear.value, currentMonth.value, 1).getDay();
  return day === 0 ? 6 : day - 1; // Приводим к Пн=0, Вс=6
});

const monthNames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const weekDays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

const prevMonth = () => {
  if (currentMonth.value === 0) {
    currentMonth.value = 11;
    currentYear.value--;
  } else {
    currentMonth.value--;
  }
};

const nextMonth = () => {
  if (currentMonth.value === 11) {
    currentMonth.value = 0;
    currentYear.value++;
  } else {
    currentMonth.value++;
  }
};
</script>

<template>
  <div class="widget calendar-widget">
    <div class="widget__header">
      <h3 class="widget__title">Календарь</h3>
      <div class="calendar-controls">
        <button @click="prevMonth" class="calendar-btn">‹</button>
        <span class="calendar-month">{{ monthNames[currentMonth] }} {{ currentYear }}</span>
        <button @click="nextMonth" class="calendar-btn">›</button>
      </div>
    </div>
    
    <div class="calendar-grid">
      <span v-for="day in weekDays" :key="day" class="calendar-weekday">{{ day }}</span>
      <span v-for="n in firstDayOfMonth" :key="'empty-' + n" class="calendar-empty"></span>
      <button 
        v-for="day in daysInMonth" 
        :key="day"
        class="calendar-day"
        :class="{ 'calendar-day--selected': day === selectedDay }"
        @click="selectedDay = day"
      >
        {{ day }}
      </button>
    </div>
  </div>
</template>

<style scoped>
.widget {
  background: var(--color-white);
  border-radius: var(--radius-md);
  padding: 20px;
  box-shadow: var(--shadow-card);
}

.widget__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.widget__title {
  font-size: 16px;
  font-weight: 600;
}

.calendar-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.calendar-btn {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: var(--color-bg-light);
  font-size: 16px;
  color: var(--color-text-muted);
}

.calendar-btn:hover {
  background: var(--color-accent);
  color: var(--color-bg-dark);
}

.calendar-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 4px;
  text-align: center;
}

.calendar-weekday {
  font-size: 11px;
  color: var(--color-text-muted);
  font-weight: 600;
  padding-bottom: 8px;
}

.calendar-day {
  aspect-ratio: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: 13px;
  transition: var(--transition);
}

.calendar-day:hover {
  background: var(--color-bg-light);
}

.calendar-day--selected {
  background: var(--color-bg-dark);
  color: var(--color-white);
  font-weight: 600;
}
</style>