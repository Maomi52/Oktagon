// src/stores/booking.js
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

export const useBookingStore = defineStore('booking', () => {
  // ============ РЕСУРСЫ ============
  const resources = ref([
    {
      id: 1,
      type: 'rooms',
      title: 'Кинозал (Аудитория)',
      description: 'Вместимость: 20 человек. Оборудование: проектор, звук.',
      image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80',
      responsible: 'Анна Смирнова',
      slots: [
        { id: '1-1', time: '08:00 - 08:45', isBooked: false },
        { id: '1-2', time: '09:00 - 09:45', isBooked: true },
        { id: '1-3', time: '10:00 - 10:45', isBooked: false },
        { id: '1-4', time: '11:00 - 11:45', isBooked: false },
        { id: '1-5', time: '12:00 - 12:45', isBooked: true },
        { id: '1-6', time: '13:00 - 13:45', isBooked: false },
        { id: '1-7', time: '14:00 - 14:45', isBooked: false },
        { id: '1-8', time: '15:00 - 15:45', isBooked: false },
      ]
    },
    {
      id: 2,
      type: 'rooms',
      title: 'Переговорная "Альфа"',
      description: 'Вместимость: 8 человек. Доска, телевизор.',
      image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&q=80',
      responsible: 'Петр Иванов',
      slots: [
        { id: '2-1', time: '08:00 - 08:45', isBooked: true },
        { id: '2-2', time: '09:00 - 09:45', isBooked: false },
        { id: '2-3', time: '10:00 - 10:45', isBooked: false },
        { id: '2-4', time: '11:00 - 11:45', isBooked: true },
        { id: '2-5', time: '12:00 - 12:45', isBooked: false },
        { id: '2-6', time: '13:00 - 13:45', isBooked: false },
        { id: '2-7', time: '14:00 - 14:45', isBooked: false },
        { id: '2-8', time: '15:00 - 15:45', isBooked: false },
      ]
    },
    {
      id: 3,
      type: 'spaces',
      title: 'Студия звукозаписи',
      description: 'Профессиональное оборудование для записи.',
      image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80',
      responsible: 'Ольга Козлова',
      slots: [
        { id: '3-1', time: '08:00 - 08:45', isBooked: false },
        { id: '3-2', time: '09:00 - 09:45', isBooked: false },
        { id: '3-3', time: '10:00 - 10:45', isBooked: false },
        { id: '3-4', time: '11:00 - 11:45', isBooked: false },
      ]
    }
  ]);

  // ============ ЛЮДИ ============
  const people = ref([
    {
      id: 101,
      type: 'people',
      title: 'Иван Иванов',
      description: 'Фотограф. Специализация: портрет, репортаж.',
      image: 'https://i.pravatar.cc/300?img=12',
      responsible: 'Иван Иванов',
      slots: [
        { id: '101-1', time: '08:00 - 08:45', isBooked: false },
        { id: '101-2', time: '09:00 - 09:45', isBooked: false },
        { id: '101-3', time: '10:00 - 10:45', isBooked: true },
        { id: '101-4', time: '11:00 - 11:45', isBooked: false },
      ]
    },
    {
      id: 102,
      type: 'people',
      title: 'Алексей Петрович',
      description: 'Видеооператор. Специализация: монтаж, съемка.',
      image: 'https://i.pravatar.cc/300?img=33',
      responsible: 'Алексей Петрович',
      slots: [
        { id: '102-1', time: '08:00 - 08:45', isBooked: true },
        { id: '102-2', time: '09:00 - 09:45', isBooked: false },
        { id: '102-3', time: '10:00 - 10:45', isBooked: false },
        { id: '102-4', time: '11:00 - 11:45', isBooked: false },
      ]
    }
  ]);

  // ============ БРОНИРОВАНИЯ ============
  const myBookings = ref([]);

  // ============ УВЕДОМЛЕНИЯ ============
  const notifications = ref([]);

  const addNotification = (message, type = 'info') => {
    notifications.value.push({
      id: Date.now(),
      message,
      type, // 'info' | 'success' | 'error'
      createdAt: new Date().toISOString(),
      isRead: false
    });
  };

  const markNotificationAsRead = (id) => {
    const notification = notifications.value.find(n => n.id === id);
    if (notification) notification.isRead = true;
  };

  const unreadNotificationsCount = computed(() => 
    notifications.value.filter(n => !n.isRead).length
  );

  // ============ ТЕКУЩИЙ ВЫБОР ============
  const currentSelection = ref({
    resourceId: null,
    resourceTitle: '',
    date: null,
    slots: []
  });

  const openBookingModal = (resourceId, resourceTitle, selectedSlots) => {
    currentSelection.value = {
      resourceId,
      resourceTitle,
      date: new Date().toISOString().split('T')[0],
      slots: selectedSlots
    };
  };

  // ============ ПРОВЕРКА КОНФЛИКТОВ ============
  const hasConflict = (resourceId, date, slots) => {
    return myBookings.value.some(booking => 
      booking.resourceId === resourceId &&
      booking.date === date &&
      booking.slots.some(s => slots.includes(s))
    );
  };

  // ============ СОЗДАНИЕ БРОНИРОВАНИЯ ============
  const createBooking = (bookingData) => {
    // 1. Проверка на конфликты
    if (hasConflict(bookingData.resourceId, bookingData.date, bookingData.slots)) {
      addNotification('Ошибка: это время уже занято!', 'error');
      throw new Error('Это время уже занято!');
    }

    // 2. Создаем запись
    const newBooking = {
      id: Date.now(),
      ...bookingData,
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };
    myBookings.value.push(newBooking);

    // 3. Обновляем слоты в ресурсе (делаем их занятыми)
    updateResourceSlots(bookingData.resourceId, bookingData.slots, true);

    // 4. Отправляем уведомления участникам
    if (bookingData.notifications?.length) {
      addNotification(
        `Уведомления отправлены: ${bookingData.notifications.join(', ')}`,
        'info'
      );
    }

    // 5. Синхронизация с календарем
    addNotification(
      `Бронирование добавлено в календарь на ${bookingData.date}`,
      'success'
    );

    return newBooking;
  };

  // ============ ОТМЕНА БРОНИРОВАНИЯ ============
  const cancelBooking = (bookingId) => {
    const booking = myBookings.value.find(b => b.id === bookingId);
    if (!booking) return;

    // Освобождаем слоты
    updateResourceSlots(booking.resourceId, booking.slots, false);
    
    // Удаляем бронирование
    myBookings.value = myBookings.value.filter(b => b.id !== bookingId);
    
    addNotification('Бронирование отменено', 'info');
  };

  // ============ ОБНОВЛЕНИЕ СЛОТОВ ============
  const updateResourceSlots = (resourceId, slotTimes, isBooked) => {
    // Ищем в ресурсах
    let resource = resources.value.find(r => r.id === resourceId);
    // Или в людях
    if (!resource) {
      resource = people.value.find(p => p.id === resourceId);
    }
    if (!resource) return;

    resource.slots.forEach(slot => {
      if (slotTimes.includes(slot.time)) {
        slot.isBooked = isBooked;
      }
    });
  };

  // ============ CRUD ДЛЯ РЕСУРСОВ (управление) ============
  const addResource = (resource) => {
    const newResource = {
      id: Date.now(),
      type: 'rooms',
      slots: generateDefaultSlots(),
      ...resource
    };
    resources.value.push(newResource);
    addNotification(`Ресурс "${resource.title}" добавлен`, 'success');
    return newResource;
  };

  const updateResource = (id, updates) => {
    const resource = resources.value.find(r => r.id === id);
    if (resource) {
      Object.assign(resource, updates);
      addNotification(`Ресурс "${resource.title}" обновлен`, 'success');
    }
  };

  const deleteResource = (id) => {
    const resource = resources.value.find(r => r.id === id);
    if (resource) {
      resources.value = resources.value.filter(r => r.id !== id);
      addNotification(`Ресурс "${resource.title}" удален`, 'info');
    }
  };

  // Генерация стандартных слотов
  const generateDefaultSlots = () => {
    const times = [
      '08:00 - 08:45', '09:00 - 09:45', '10:00 - 10:45', '11:00 - 11:45',
      '12:00 - 12:45', '13:00 - 13:45', '14:00 - 14:45', '15:00 - 15:45'
    ];
    return times.map((time, index) => ({
      id: `${Date.now()}-${index}`,
      time,
      isBooked: false
    }));
  };

  // ============ ПОИСК И ФИЛЬТРАЦИЯ ============
  const searchQuery = ref('');
  
  const filteredResources = computed(() => {
    if (!searchQuery.value) return resources.value;
    const query = searchQuery.value.toLowerCase();
    return resources.value.filter(r => 
      r.title.toLowerCase().includes(query) ||
      r.description.toLowerCase().includes(query)
    );
  });

  return {
    // Данные
    resources,
    people,
    myBookings,
    notifications,
    currentSelection,
    searchQuery,
    unreadNotificationsCount,
    filteredResources,
    
    // Методы
    openBookingModal,
    createBooking,
    cancelBooking,
    addResource,
    updateResource,
    deleteResource,
    addNotification,
    markNotificationAsRead,
    hasConflict
  };
});