<!-- src/views/LandingView.vue -->
<script setup>
import { useRouter } from 'vue-router';
const router = useRouter();

const goTo = (path) => router.push(path);
</script>

<template>
  <div class="landing">
    <!-- В LandingView.vue в шапке -->
<header class="landing__header">
  <div class="logo" @click="$router.push('/')">
    <span class="logo__icon">✎</span> СБР
  </div>
  <nav class="nav">
    <a href="#" class="nav__link" @click.prevent="$router.push('/dashboard')">Авторизация</a>
    <a href="#" class="nav__link" @click.prevent="$router.push('/dashboard')">Люди</a>
    <a href="#" class="nav__link" @click.prevent="$router.push('/dashboard')">Пространства</a>
    <a href="#" class="nav__link" @click.prevent="$router.push('/profile')">Профиль</a>
  </nav>
</header>

    <!-- Главный баннер -->
    <main class="hero">
      <div class="hero__content">
        <h1 class="hero__title">
          Сервис бронирования<br>ресурсов
        </h1>
        <p class="hero__subtitle">
          Разработка инструментов, предназначенных для эффективного<br>
          управления бронированием общих ресурсов.
        </p>
        
        <!-- В LandingView.vue в блоке hero__actions -->
<div class="hero__actions">
  <button class="btn btn--primary" @click="$router.push('/dashboard')">Вход</button>
  <button class="btn btn--outline" @click="$router.push('/dashboard')">Регистрация</button>
</div>
      </div>
    </main>
  </div>
</template>

<style scoped>
.landing {
  min-height: 100vh;
  background-image: linear-gradient(
      rgba(10, 42, 31, 0.85), 
      rgba(10, 42, 31, 0.95)
    ), 
    url('https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80'); /* Замените на вашу картинку */
  background-size: cover;
  background-position: center;
  color: var(--color-white);
  display: flex;
  flex-direction: column;
}

/* Шапка */
.landing__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 48px;
}

.logo {
  font-size: 24px;
  font-weight: 700;
  display: flex;
  align-items: center;
  gap: 8px;
}

.logo__icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border: 2px solid var(--color-white);
  border-radius: 8px;
  font-size: 18px;
}

.nav {
  display: flex;
  gap: 32px;
}

.nav__link {
  color: rgba(255, 255, 255, 0.8);
  font-size: 14px;
  transition: var(--transition);
}

.nav__link:hover {
  color: var(--color-white);
}

/* Hero-секция */
.hero {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 0 24px;
}

.hero__content {
  max-width: 800px;
}

.hero__title {
  font-size: 56px;
  font-weight: 700;
  line-height: 1.2;
  margin-bottom: 24px;
  letter-spacing: -1px;
}

.hero__subtitle {
  font-size: 16px;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 40px;
  line-height: 1.6;
}

.hero__actions {
  display: flex;
  gap: 16px;
  justify-content: center;
}

.hero__actions .btn {
  min-width: 160px;
}

/* Адаптивность */
@media (max-width: 768px) {
  .landing__header {
    padding: 16px 20px;
    flex-direction: column;
    gap: 16px;
  }
  
  .nav {
    gap: 16px;
    flex-wrap: wrap;
    justify-content: center;
  }

  .hero__title {
    font-size: 36px;
  }
  
  .hero__actions {
    flex-direction: column;
    width: 100%;
  }
  
  .hero__actions .btn {
    width: 100%;
  }
}
</style>