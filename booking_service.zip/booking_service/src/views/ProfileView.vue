<!-- src/views/ProfileView.vue -->
<script setup>
import { useRouter } from 'vue-router';
import { useBookingStore } from '../stores/booking';
import AppHeader from '../components/layout/AppHeader.vue';

const router = useRouter();
const bookingStore = useBookingStore();

const formatDate = (dateStr) => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('ru-RU', { 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric' 
  });
};

const handleCancel = (bookingId) => {
  if (confirm('Вы уверены, что хотите отменить бронирование?')) {
    bookingStore.cancelBooking(bookingId);
  }
};
</script>

<template>
  <div class="profile">
<AppHeader :show-search="false" />

    <div class="profile__content">
      <div class="profile__user">
        <div class="profile__avatar"></div>
        <div>
          <h1 class="profile__name">Иван Петров</h1>
          <p class="profile__role">Менеджер проектов</p>
        </div>
      </div>

      <h2 class="profile__section-title">
        Мои бронирования 
        <span class="badge">{{ bookingStore.myBookings.length }}</span>
      </h2>

      <div v-if="bookingStore.myBookings.length === 0" class="empty-state">
        <p>У вас пока нет бронирований</p>
        <button class="btn btn--primary" @click="router.push('/dashboard')">
          Забронировать ресурс
        </button>
      </div>

      <div v-else class="bookings-list">
        <div 
          v-for="booking in bookingStore.myBookings" 
          :key="booking.id" 
          class="booking-card"
        >
          <div class="booking-card__header">
            <h3 class="booking-card__title">{{ booking.resourceTitle }}</h3>
            <span class="booking-card__status">Подтверждено</span>
          </div>

          <div class="booking-card__info">
            <div class="info-row">
              <span class="info-label">Дата:</span>
              <span class="info-value">{{ formatDate(booking.date) }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Время:</span>
              <div class="info-slots">
                <span v-for="slot in booking.slots" :key="slot" class="slot-chip">
                  {{ slot }}
                </span>
              </div>
            </div>
            <div v-if="booking.comment" class="info-row">
              <span class="info-label">Комментарий:</span>
              <span class="info-value">{{ booking.comment }}</span>
            </div>
            <div v-if="booking.notifications?.length" class="info-row">
              <span class="info-label">Уведомлены:</span>
              <span class="info-value">{{ booking.notifications.join(', ') }}</span>
            </div>
          </div>

          <div class="booking-card__actions">
            <button class="btn btn--outline btn--danger" @click="handleCancel(booking.id)">
              Отменить бронирование
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.profile {
  min-height: 100vh;
  background-color: var(--color-bg-light);
}

.profile__content {
  max-width: 900px;
  margin: 0 auto;
  padding: 32px;
}

.profile__user {
  display: flex;
  align-items: center;
  gap: 20px;
  padding: 24px;
  background: var(--color-white);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-card);
  margin-bottom: 32px;
}

.profile__avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background-image: url('https://i.pravatar.cc/150?img=12');
  background-size: cover;
}

.profile__name {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 4px;
}

.profile__role {
  font-size: 14px;
  color: var(--color-text-muted);
}

.profile__section-title {
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 12px;
}

.badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 28px;
  height: 28px;
  padding: 0 8px;
  background: var(--color-accent);
  color: var(--color-bg-dark);
  border-radius: 14px;
  font-size: 13px;
  font-weight: 600;
}

.empty-state {
  text-align: center;
  padding: 60px 24px;
  background: var(--color-white);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-card);
  color: var(--color-text-muted);
}

.empty-state p {
  margin-bottom: 20px;
  font-size: 15px;
}

.bookings-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.booking-card {
  background: var(--color-white);
  border-radius: var(--radius-md);
  padding: 24px;
  box-shadow: var(--shadow-card);
}

.booking-card__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--color-border);
}

.booking-card__title {
  font-size: 18px;
  font-weight: 600;
}

.booking-card__status {
  font-size: 12px;
  padding: 4px 12px;
  background: #E8F8F0;
  color: #27AE60;
  border-radius: 12px;
  font-weight: 500;
}

.booking-card__info {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 20px;
}

.info-row {
  display: flex;
  gap: 12px;
  font-size: 14px;
}

.info-label {
  color: var(--color-text-muted);
  min-width: 130px;
}

.info-value {
  color: var(--color-text-main);
}

.info-slots {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.slot-chip {
  padding: 4px 10px;
  background: var(--color-accent);
  color: var(--color-bg-dark);
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}

.booking-card__actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

.btn--danger {
  border-color: #E74C3C;
  color: #E74C3C;
}

.btn--danger:hover {
  background: #E74C3C;
  color: white;
}
</style>