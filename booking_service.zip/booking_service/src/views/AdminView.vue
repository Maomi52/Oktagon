<!-- src/views/AdminView.vue -->
<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useBookingStore } from '../stores/booking';
import BaseModal from '../components/ui/BaseModal.vue';
import AppHeader from '../components/layout/AppHeader.vue';

const router = useRouter();
const bookingStore = useBookingStore();

const isModalOpen = ref(false);
const editingResource = ref(null);

const form = ref({
  title: '',
  description: '',
  image: '',
  responsible: '',
  type: 'rooms'
});

const openCreateModal = () => {
  editingResource.value = null;
  form.value = { title: '', description: '', image: '', responsible: '', type: 'rooms' };
  isModalOpen.value = true;
};

const openEditModal = (resource) => {
  editingResource.value = resource;
  form.value = { ...resource };
  isModalOpen.value = true;
};

const handleSubmit = () => {
  if (editingResource.value) {
    bookingStore.updateResource(editingResource.value.id, form.value);
  } else {
    bookingStore.addResource(form.value);
  }
  isModalOpen.value = false;
};

const handleDelete = (id) => {
  if (confirm('Удалить этот ресурс?')) {
    bookingStore.deleteResource(id);
  }
};
</script>

<template>
  <div class="admin">
   <AppHeader :show-search="false" />

    <div class="admin__content">
      <div class="admin__top">
        <h1 class="admin__title">Управление ресурсами</h1>
        <button class="btn btn--primary" @click="openCreateModal">
          + Добавить ресурс
        </button>
      </div>

      <div class="resources-table">
        <div class="table-header">
          <div class="table-cell">Название</div>
          <div class="table-cell">Тип</div>
          <div class="table-cell">Ответственный</div>
          <div class="table-cell">Действия</div>
        </div>

        <div 
          v-for="resource in bookingStore.resources" 
          :key="resource.id" 
          class="table-row"
        >
          <div class="table-cell">
            <div class="resource-info">
              <img :src="resource.image" class="resource-thumb" />
              <div>
                <div class="resource-title">{{ resource.title }}</div>
                <div class="resource-desc">{{ resource.description }}</div>
              </div>
            </div>
          </div>
          <div class="table-cell">
            <span class="type-badge">{{ resource.type }}</span>
          </div>
          <div class="table-cell">{{ resource.responsible || '—' }}</div>
          <div class="table-cell">
            <div class="actions">
              <button class="btn-icon" @click="openEditModal(resource)" title="Редактировать">✎</button>
              <button class="btn-icon btn-icon--danger" @click="handleDelete(resource.id)" title="Удалить">🗑</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Модалка создания/редактирования -->
    <BaseModal 
      :is-open="isModalOpen" 
      :title="editingResource ? 'Редактировать ресурс' : 'Новый ресурс'"
      @close="isModalOpen = false"
    >
      <form class="admin-form" @submit.prevent="handleSubmit">
        <div class="form-group">
          <label class="form-label">Название</label>
          <input v-model="form.title" class="form-input" required />
        </div>

        <div class="form-group">
          <label class="form-label">Описание</label>
          <textarea v-model="form.description" class="form-textarea" rows="3"></textarea>
        </div>

        <div class="form-group">
          <label class="form-label">Ссылка на изображение</label>
          <input v-model="form.image" class="form-input" placeholder="https://..." />
        </div>

        <div class="form-group">
          <label class="form-label">Ответственный</label>
          <input v-model="form.responsible" class="form-input" />
        </div>

        <div class="form-group">
          <label class="form-label">Тип</label>
          <select v-model="form.type" class="form-input">
            <option value="rooms">Аудитория</option>
            <option value="spaces">Пространство</option>
            <option value="people">Человек</option>
          </select>
        </div>

        <div class="form-actions">
          <button type="button" class="btn btn--outline" @click="isModalOpen = false">Отмена</button>
          <button type="submit" class="btn btn--primary">
            {{ editingResource ? 'Сохранить' : 'Создать' }}
          </button>
        </div>
      </form>
    </BaseModal>
  </div>
</template>

<style scoped>
.admin {
  min-height: 100vh;
  background-color: var(--color-bg-light);
}

.admin__content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px;
}

.admin__top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.admin__title {
  font-size: 24px;
  font-weight: 600;
}

.resources-table {
  background: var(--color-white);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-card);
  overflow: hidden;
}

.table-header,
.table-row {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1fr;
  gap: 16px;
  padding: 16px 24px;
  align-items: center;
}

.table-header {
  background: var(--color-bg-light);
  font-size: 12px;
  font-weight: 600;
  color: var(--color-text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.table-row {
  border-top: 1px solid var(--color-border);
  transition: var(--transition);
}

.table-row:hover {
  background: var(--color-bg-light);
}

.resource-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.resource-thumb {
  width: 48px;
  height: 48px;
  border-radius: var(--radius-sm);
  object-fit: cover;
}

.resource-title {
  font-weight: 500;
  font-size: 14px;
  margin-bottom: 2px;
}

.resource-desc {
  font-size: 12px;
  color: var(--color-text-muted);
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.type-badge {
  display: inline-block;
  padding: 4px 10px;
  background: var(--color-bg-light);
  border-radius: 12px;
  font-size: 12px;
  text-transform: capitalize;
}

.actions {
  display: flex;
  gap: 8px;
}

.btn-icon {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-sm);
  background: var(--color-bg-light);
  transition: var(--transition);
  font-size: 14px;
}

.btn-icon:hover {
  background: var(--color-accent);
}

.btn-icon--danger:hover {
  background: #FDEDEC;
}

/* Форма */
.admin-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--color-text-muted);
}

.form-input,
.form-textarea {
  padding: 10px 14px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  font-size: 14px;
  font-family: inherit;
  outline: none;
  transition: var(--transition);
  background: var(--color-bg-light);
}

.form-input:focus,
.form-textarea:focus {
  border-color: var(--color-accent);
  background: var(--color-white);
}

.form-actions {
  display: flex;
  gap: 12px;
  margin-top: 8px;
}

.form-actions .btn {
  flex: 1;
}
</style>