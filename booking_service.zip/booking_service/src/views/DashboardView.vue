<!-- src/views/DashboardView.vue -->
<script setup>
import { ref, computed } from 'vue';
import { useBookingStore } from '../stores/booking';
import ResourceCard from '../components/dashboard/ResourceCard.vue';
import CalendarWidget from '../components/dashboard/CalendarWidget.vue';
import ActiveOffers from '../components/dashboard/ActiveOffers.vue';
import OrgStructure from '../components/dashboard/OrgStructure.vue';
import BookingModal from '../components/ui/BookingModal.vue';
import SuccessModal from '../components/ui/SuccessModal.vue';
import AppHeader from '../components/layout/AppHeader.vue';

const bookingStore = useBookingStore();

const activeTab = ref('rooms');
const tabs = [
  { id: 'rooms', label: 'Аудитории' },
  { id: 'people', label: 'Люди' },
  { id: 'spaces', label: 'Пространства' }
];

const isBookingModalOpen = ref(false);
const isSuccessModalOpen = ref(false);

// Список отображаемых карточек в зависимости от таба
const displayedResources = computed(() => {
  let list;
  if (activeTab.value === 'people') {
    list = bookingStore.people;
  } else {
    list = bookingStore.resources.filter(r => r.type === activeTab.value);
    if (activeTab.value === 'rooms') {
      list = bookingStore.resources;
    }
  }
  
  // Фильтр по поиску
  if (bookingStore.searchQuery) {
    const q = bookingStore.searchQuery.toLowerCase();
    list = list.filter(r => 
      r.title.toLowerCase().includes(q) || 
      r.description.toLowerCase().includes(q)
    );
  }
  
  return list;
});

// Обработка клика "Забронировать" в карточке
const handleBook = ({ resourceId, resourceTitle, slots }) => {
  bookingStore.openBookingModal(resourceId, resourceTitle, slots);
  isBookingModalOpen.value = true;
};

const handleBookingSuccess = () => {
  isSuccessModalOpen.value = true;
};
</script>

<template>
<AppHeader :show-search="true" />
  <div class="dashboard">

    <!-- Контент -->
    <div class="dashboard__content">
      <section class="dashboard__main">
        <div class="tabs">
          <button 
            v-for="tab in tabs" 
            :key="tab.id"
            class="tabs__item"
            :class="{ 'tabs__item--active': activeTab === tab.id }"
            @click="activeTab = tab.id"
          >
            {{ tab.label }}
          </button>
        </div>

        <div class="resources-list">
          <ResourceCard 
            v-for="resource in displayedResources" 
            :key="resource.id"
            :id="resource.id"
            :title="resource.title"
            :description="resource.description"
            :image="resource.image"
            :slots="resource.slots"
            :is-people="resource.type === 'people'"
            @book="handleBook"
          />
        </div>
      </section>

      <aside class="dashboard__sidebar">
        <CalendarWidget />
        <ActiveOffers />
        <OrgStructure />
      </aside>
    </div>

    <!-- Модалки -->
    <BookingModal 
      :is-open="isBookingModalOpen" 
      @close="isBookingModalOpen = false"
      @success="handleBookingSuccess"
    />
    <SuccessModal 
      :is-open="isSuccessModalOpen" 
      @close="isSuccessModalOpen = false"
    />
  </div>
</template>

<style scoped>
/* Стили остаются из предыдущей версии */
.dashboard {
  min-height: 100vh;
  background-color: var(--color-bg-light);
  display: flex;
  flex-direction: column;
}

.dashboard__content {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 32px;
  padding: 32px;
  max-width: 1440px;
  margin: 0 auto;
  width: 100%;
}

.tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 24px;
}

.tabs__item {
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-muted);
  background: transparent;
  transition: var(--transition);
}

.tabs__item--active {
  background: var(--color-bg-dark);
  color: var(--color-white);
}

.resources-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.dashboard__sidebar {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

@media (max-width: 1024px) {
  .dashboard__content {
    grid-template-columns: 1fr;
  }
  
  .dashboard__header {
    flex-wrap: wrap;
    gap: 16px;
  }
  
  .search-bar__input {
    width: 100%;
  }
}
</style>